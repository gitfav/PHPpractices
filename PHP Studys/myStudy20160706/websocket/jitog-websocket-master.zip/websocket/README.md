#websocket
## demo
<http://www.yxsss.com/ui/sk.html>

